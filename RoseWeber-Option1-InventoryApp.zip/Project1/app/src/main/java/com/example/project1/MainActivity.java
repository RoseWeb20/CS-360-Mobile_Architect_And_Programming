package com.example.project1;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.database.DataSetObserver;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Adapter;
import android.widget.ArrayAdapter;
import android.widget.Switch;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;
import java.util.List;
import java.util.Arrays;
import java.util.Locale;

public class MainActivity extends AppCompatActivity {

    //Get instance of recycler view objects
    private RecyclerView recyclerView;
    private RecyclerView.Adapter adapter;
    private RecyclerView.LayoutManager layoutManager;

    public Switch sw_ActiveItem;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        //Get all items from database
        ItemDBHelper db = new ItemDBHelper(MainActivity.this);
        List<ItemModel> allItems = db.getItems();

        //Assign recycler view
        recyclerView = findViewById(R.id.itemListView);
        recyclerView.setHasFixedSize(true);

        //Assign layout manager to recycler view
        layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        //Assign adapter to recycler view
        adapter = new RecyclerViewAdapter(allItems, this);
        recyclerView.setAdapter(adapter);

    }

    //Add settings icon to top menu
    public boolean onCreateOptionsMenu(Menu menu) {
        // Inflate the menu; this adds items to the action bar if it is present.
        getMenuInflater().inflate(R.menu.menu, menu);
        return true;
    }

    //Switch to DetailActivity
    public void AddItem(View view)
    {
        Intent switchActivityIntent = new Intent(this, DetailActivity.class);
        startActivity(switchActivityIntent);
    }

    //Switch to SettingsActivity
    public void GoToSettings()
    {
        Intent switchActivityIntent = new Intent(this, SettingsActivity.class);
        startActivity(switchActivityIntent);
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        // Handle item selection
        switch (item.getItemId()) {
            case R.id.add:
                GoToSettings();
                return true;
            default:
                return super.onOptionsItemSelected(item);
        }
    }

}
