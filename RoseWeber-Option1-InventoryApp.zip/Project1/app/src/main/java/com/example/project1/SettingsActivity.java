package com.example.project1;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.widget.CompoundButton;
import android.widget.Switch;

import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.preference.PreferenceFragmentCompat;

public class SettingsActivity extends AppCompatActivity {

    //Get instance of switch
    Switch settingSwitch;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.settings_activity);

        //Get instance of shared prefs to set notification pref
        SharedPreferences sharedPref = this.getSharedPreferences(getString(R.string.settingsFile), Context.MODE_PRIVATE);

        //Assign switch to on screen element
        settingSwitch = findViewById(R.id.switch1);

        //Set default switch position based on notification preference
        settingSwitch.setChecked(sharedPref.getBoolean(getString(R.string.allowNotifications), false));

        settingSwitch.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                if(isChecked) // If switched to checked. Open shared prefs and assign value to true
                {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.allowNotifications), true);
                    editor.apply();
                }
                else // If switched to unchecked. Open shared prefs and assign value to false
                {
                    SharedPreferences.Editor editor = sharedPref.edit();
                    editor.putBoolean(getString(R.string.allowNotifications), false);
                    editor.apply();
                }
            }
        });

    }



}