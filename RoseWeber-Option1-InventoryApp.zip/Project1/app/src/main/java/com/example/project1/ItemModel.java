package com.example.project1;

public class ItemModel {
    //This class serves as a model for each item in the inventory database and should be used to hold each
    //item's information before it is placed into the inventory database and then again after it is retrieved
    private int id;
    private String name;
    private String description;
    private int quantity;

    public ItemModel(int id, String name, String description, int quantity) {
        this.id = id;
        this.name = name;
        this.description = description;
        this.quantity = quantity;
    }

    //Getters and Setters for each variable.
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getQuantity() {
        return quantity;
    }

    public void setQuantity(int quantity) {
        this.quantity = quantity;
    }
}
