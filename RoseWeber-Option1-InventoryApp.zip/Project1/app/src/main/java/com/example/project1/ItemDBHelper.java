package com.example.project1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;

import java.io.PrintStream;
import java.util.ArrayList;
import java.util.List;

public class ItemDBHelper extends SQLiteOpenHelper {

    //Variables for Column and table names.
    public static final String ITEMS = "ITEMS";
    public static final String COLUMN_ITEM_NAME = "ITEM_NAME";
    public static final String COLUMN_ITEM_DESCRIPTION = "ITEM_DESCRIPTION";
    public static final String COLUMN_ITEM_QUANTITY = "ITEM_QUANTITY";
    public static final String COLUMN_ID = "ID";

    //Constructor
    public ItemDBHelper(@Nullable Context context) {
        super(context, "ItemDatabase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + ITEMS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_ITEM_NAME + " TEXT,  " + COLUMN_ITEM_DESCRIPTION + " TEXT, " + COLUMN_ITEM_QUANTITY + " INT) ";

        sqLiteDatabase.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    //Add item to database
    public boolean AddItem(ItemModel itemModel)
    {
        //Open database
        SQLiteDatabase db = this.getWritableDatabase();

        //Create temp CV for item information
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_ITEM_DESCRIPTION, itemModel.getDescription());
        cv.put(COLUMN_ITEM_NAME, itemModel.getName());
        cv.put(COLUMN_ITEM_QUANTITY, itemModel.getQuantity());

        //Add to inventory and return result.
        long result = db.insert(ITEMS, null, cv);

        //Return result to user.
        if(result == -1)
        {
            return false;
        }
        else{
            return true;
        }

    }

    //Update Item from inventory
    public boolean updateItem(int id, ItemModel updatedItem) {

        //Open database
        SQLiteDatabase db = this.getWritableDatabase();

        //Create cv for updated values.
        ContentValues values = new ContentValues();
        values.put(COLUMN_ITEM_QUANTITY, updatedItem.getQuantity());
        values.put(COLUMN_ITEM_NAME, updatedItem.getName());
        values.put(COLUMN_ITEM_DESCRIPTION, updatedItem.getDescription());

        //Update item and return result
        int rowsUpdated = db.update(ITEMS, values, "ID = ?",
                new String[] { Float.toString(id) });
        return rowsUpdated > 0;
    }

    //Delete Item from database
    public boolean deleteItem(int id) {
        //Open database
        SQLiteDatabase db = getWritableDatabase();

        //Delete item from database where id matches id parameter and return result
        int rowsDeleted = db.delete(ITEMS, COLUMN_ID + " = ?",
                new String[] { Long.toString(id) });
        return rowsDeleted > 0;
    }

    public ItemModel getOne(String id)
    {
        //Create item model
        ItemModel item;


        //String queryString = "SELECT * FROM " + ITEMS + " WHERE " + COLUMN_ID + "=" + id;

        //Open Database
        SQLiteDatabase db = this.getReadableDatabase();

        //Read item from database
        Cursor result = db.query(ITEMS,
                new String[]{COLUMN_ID,COLUMN_ITEM_NAME, COLUMN_ITEM_DESCRIPTION, COLUMN_ITEM_QUANTITY},
                COLUMN_ID + "=?",
                new String[]{String.valueOf(id)}, null, null, null, null);

        //Create variables for database result information
        int itemID = result.getInt(0);
        String itemName = result.getString(1);
        String itemDescription = result.getString(2);
        int itemQuantity = result.getInt(3);

        //Assign item model with return variables
        item = new ItemModel(itemID, itemName, itemDescription, itemQuantity);

        //close database and cursor
        result.close();
        db.close();

        //Return the itemModel
        return item;
    }

    //Get all items from database and return as list of ItemModel objects
    public List<ItemModel> getItems()
    {
        //Create list to return
        List<ItemModel> returnlist = new ArrayList<>();

        //String to read all items in ITEMS database table.
        String queryString = "SELECT * FROM " + ITEMS;

        //Open database
        SQLiteDatabase db = this.getReadableDatabase();

        //Read items from database
        Cursor result = db.rawQuery(queryString, null);

        //While there are items to be read, create temp variables for current item then create a new Item
        //Model object then add item to list.
        if(result.moveToFirst())
        {
            do{
                int itemID = result.getInt(0);
                String itemName = result.getString(1);
                String itemDescription = result.getString(2);
                int itemQuantity = result.getInt(3);


                ItemModel item = new ItemModel(itemID, itemName, itemDescription, itemQuantity);
                returnlist.add(item);
            }while(result.moveToNext());
        }
        else
        {
            //No items returned.
        }

        //Close database and cursor then return list
        result.close();
        db.close();
        return returnlist;
    }
}
