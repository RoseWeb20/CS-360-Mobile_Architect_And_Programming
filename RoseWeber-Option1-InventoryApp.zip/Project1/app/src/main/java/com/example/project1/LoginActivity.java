package com.example.project1;

import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class LoginActivity extends AppCompatActivity {

    //Get input fields.
    TextView usernameText;
    TextView passwordText;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_login);

        //Link on screen elements to input fields.
        usernameText = (TextView) findViewById(R.id.usernameInput);
        passwordText = (TextView) findViewById(R.id.passwordInput);

    }

    //To Switch to MainActivity Screen
    public void switchActivities(View view)
    {
        Intent switchActivityIntent = new Intent(this, MainActivity.class);
        startActivity(switchActivityIntent);
    }

    //To check the input field creds against user database
    public void checkCreds(View view)
    {
        //Get instance of user database
        UserDBHelper db = new UserDBHelper(LoginActivity.this);

        //Check input fields against user database and return result
        boolean result = db.checkCredentials(usernameText.getText().toString(), passwordText.getText().toString(), this);

        //Switch screens if authorized.
        if(result)
        {
            switchActivities(view);
        }
    }

    //Register user
    public void registerUser(View view) {
        //Create new UserModel with input field strings.
        UserModel newUser = new UserModel(usernameText.getText().toString(), passwordText.getText().toString());

        //Get instance of user database.
        UserDBHelper db = new UserDBHelper(LoginActivity.this);
        //Add user and return result.
        boolean result = db.AddUser(newUser);

        //Display result to user
        if (result) {
            Toast.makeText(LoginActivity.this, "Registration successful!", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(LoginActivity.this, "Registration Failed. Please try again", Toast.LENGTH_SHORT).show();
        }
    }
}