package com.example.project1;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;


import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.MyViewHolder> {

    List<ItemModel> itemList;
    Context context;
    public ItemModel activeItem;

    public RecyclerViewAdapter(List<ItemModel> allItems, Context context) {
        this.itemList = allItems;
        this.context = context;

    }

    @NonNull
    @Override
    public MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_item, parent, false);
        MyViewHolder holder = new MyViewHolder(view);

        return holder;

    }

    @Override
    public void onBindViewHolder(@NonNull MyViewHolder holder, int position) {
        int p = position;
        holder.itemNameLV.setText(itemList.get(position).getName());
        holder.itemQuantityLV.setText("Quantity: " + String.valueOf(itemList.get(position).getQuantity()));
        holder.itemDescriptionLV.setText(itemList.get(position).getDescription());
        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent switchActivityIntent =  new Intent(context, DetailActivity.class);
                switchActivityIntent.putExtra("NewItem", false);
                switchActivityIntent.putExtra("Item ID", itemList.get(p).getId());
                switchActivityIntent.putExtra("Name", itemList.get(p).getName());
                switchActivityIntent.putExtra("Quantity", itemList.get(p).getQuantity());
                switchActivityIntent.putExtra("Description", itemList.get(p).getDescription());
                context.startActivity(switchActivityIntent);
            }
        });

    }

    @Override
    public int getItemCount() {
    return itemList.size();
    }

    public class MyViewHolder extends RecyclerView.ViewHolder{
        TextView itemNameLV;
        TextView itemQuantityLV;
        TextView itemDescriptionLV;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            itemNameLV = itemView.findViewById(R.id.itemNameLV);
            itemDescriptionLV = itemView.findViewById(R.id.itemDescriptionLV);
            itemQuantityLV = itemView.findViewById(R.id.itemQuantityLV);
        }
    }
}
