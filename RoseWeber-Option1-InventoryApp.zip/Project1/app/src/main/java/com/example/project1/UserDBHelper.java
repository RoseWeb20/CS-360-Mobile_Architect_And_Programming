package com.example.project1;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.Nullable;

import java.util.ArrayList;
import java.util.List;

public class UserDBHelper extends SQLiteOpenHelper {

    //Variables for Column and table names.
    public static final String USERS = "USERS";
    public static final String COLUMN_USERNAME = "USERNAME";
    public static final String COLUMN_PASSWORD = "PASSWORD";
    public static final String COLUMN_ID = "ID";

    //Constructor
    public UserDBHelper(@Nullable Context context) {
        super(context, "UserDatabase", null, 1);
    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        String createTable = "CREATE TABLE " + USERS + " (" + COLUMN_ID + " INTEGER PRIMARY KEY AUTOINCREMENT, " + COLUMN_USERNAME + " TEXT,  " + COLUMN_PASSWORD + " TEXT) ";

        sqLiteDatabase.execSQL(createTable);

    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {

    }

    //Add user to database
    public boolean AddUser(UserModel userModel)
    {
        //Open database
        SQLiteDatabase db = this.getWritableDatabase();

        //Create temp CV for user information
        ContentValues cv = new ContentValues();
        cv.put(COLUMN_USERNAME, userModel.getUsername());
        cv.put(COLUMN_PASSWORD, userModel.getPassword());

        //Add to database and return result.
        long result = db.insert(USERS, null, cv);
        if(result == -1)
        {
            return false;
        }
        else{
            return true;
        }
    }

    //To Check the credential parameters against the database and return a true or false value
    public boolean checkCredentials(String username, String password, Context context)
    {
        //Create query to search for username
        String queryString = "SELECT * FROM " + USERS + " WHERE " + COLUMN_USERNAME + " ='" + username + "'";

        //Open database
        SQLiteDatabase db = this.getReadableDatabase();

        //Search for user and return result
        Cursor result = db.rawQuery(queryString, null);

        //If it exists
        if(result.moveToFirst())
        {
            String pass = result.getString(2); //Get password

            if(pass.equals(password)) //If match close db and cursor then return true
            {
                result.close();
                db.close();
                return true;
            }
            else // Password doesn't match password for this username, close db and cursor, return false and inform user.
            {
                Toast.makeText(context, "Password or Username is incorrect. Please try again", Toast.LENGTH_SHORT).show();
                result.close();
                db.close();
                return false;
            }
        }
        else //username doesn't exist. close db and cursor, return false and inform user.
        {
            Toast.makeText(context, "User not found. Please Register Now.", Toast.LENGTH_SHORT).show();
            result.close();
            db.close();
            return false;
        }

    }
}
