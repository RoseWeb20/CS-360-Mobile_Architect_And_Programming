package com.example.project1;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.database.Cursor;
import android.os.Build;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.widget.Toolbar;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import java.util.List;
import java.util.Random;


public class DetailActivity extends AppCompatActivity {

    public static final int LOW_STOCK_NOTIF_ID = 888;

    //Get Input Objects
    EditText itemName;
    EditText itemDescription;
    EditText itemQuantity;

    Button saveEditButton;
    Button revertDeleteButton;

    //State Variables
    Boolean onEditingMode = false;
    Boolean isNewItem;
    Boolean newItem = false;
    Boolean allowNotifications;

    //Variables for active item
    Integer activeItemID;
    String activeItemName;
    Integer activeItemQuantity;
    String activeItemDescription;

    //For Allow Notifications preference variable
    SharedPreferences sharedPref;

    //For Low Stock Notification
    NotificationManagerCompat notificationManager;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_detail);

        //Create channel for low stock notification
        createNotificationChannel();
        notificationManager = NotificationManagerCompat.from(this);

        //Get notification preference
        SharedPreferences sharedPref = this.getSharedPreferences(getString(R.string.settingsFile), Context.MODE_PRIVATE);
        allowNotifications = sharedPref.getBoolean(getString(R.string.allowNotifications), false);

        //Link Screen elements
        itemName = (EditText) findViewById(R.id.itemNameInput);
        itemDescription = (EditText) findViewById(R.id.itemDescriptionInput);
        itemQuantity = (EditText) findViewById(R.id.itemQuantityInput);
        saveEditButton = findViewById(R.id.editSaveButton);
        revertDeleteButton = findViewById(R.id.revertDeleteButton);

        //Get item information from MainActivity Screen
        isNewItem = getIntent().getBooleanExtra("NewItem", true);
        activeItemID = getIntent().getIntExtra("Item ID", 0);
        activeItemName = getIntent().getStringExtra("Name");
        activeItemQuantity = getIntent().getIntExtra("Quantity", 0);
        activeItemDescription = getIntent().getStringExtra("Description");

        //If an item from the inventory list was selected. Fill item info to input fields.
        if(isNewItem == false)
        {
            newItem = false;
            itemName.setText(activeItemName);
            itemDescription.setText(activeItemDescription);
            itemQuantity.setText(String.valueOf(activeItemQuantity));
        }
        else //Otherwise, setup a blank entry page.
        {
            newItem = true;
            onEditingMode = true;
            itemName.setEnabled(true);
            itemDescription.setEnabled(true);
            itemQuantity.setEnabled(true);
            saveEditButton.setText("Save");
            revertDeleteButton.setText("Revert");
        }

    }

    //Change state on click of Delete/Revert button
    public void SwitchModeRemove(View view)
    {

        //input fields are enabled when button was clicked, change button text
        //disable input fields and reset input values
        if(onEditingMode)
        {
            saveEditButton.setText("Edit");
            revertDeleteButton.setText("Delete");
            itemName.setEnabled(false);
            itemQuantity.setEnabled(false);
            itemDescription.setEnabled(false);
            itemName.setText(activeItemName);
            itemDescription.setText(activeItemDescription);
            itemQuantity.setText(String.valueOf(activeItemQuantity));

        }
        else //Input fields are not enabled, delete item
        {
            deleteItem(view);
        }

        onEditingMode = !onEditingMode;

    }

    //Change state on click of Save/Edit button
    public void SwitchModeAdd(View view)
    {

        //Currently editing, change button text and disable input fields.
        //Then if item is new, register item into inventory, otherwise update the current item.
        if(onEditingMode)
        {
            saveEditButton.setText("Edit");
            revertDeleteButton.setText("Delete");
            itemName.setEnabled(false);
            itemQuantity.setEnabled(false);
            itemDescription.setEnabled(false);
            if(newItem == true)
            {
                registerItem(view);
            }
            else {
                updateItem(view);
            }
        }
        else //Not editing yet, Change button text and enable editing in fields.
        {
            saveEditButton.setText("Save");
            revertDeleteButton.setText("Revert");
            itemName.setEnabled(true);
            itemQuantity.setEnabled(true);
            itemDescription.setEnabled(true);
        }

        onEditingMode = !onEditingMode;

    }


    //Add item to inventory based on input fields.
    public void registerItem(View view) {
        //create new item model with input field information
        ItemModel newItem = new ItemModel(1, itemName.getText().toString(), itemDescription.getText().toString(), Integer.parseInt(itemQuantity.getText().toString()));

        //Get instance of item database.
        ItemDBHelper db = new ItemDBHelper(DetailActivity.this);

        //Add item to database and return result
        boolean result = db.AddItem(newItem);
        if (result) { //If item added successfully, send toast and switch to main page.
            Toast.makeText(DetailActivity.this, "Item Added Sucessfully", Toast.LENGTH_LONG).show();
            Intent switchActivityIntent = new Intent(this, MainActivity.class);
            startActivity(switchActivityIntent);
        } else {//If item added unsuccessfully, send toast.
            Toast.makeText(DetailActivity.this, "Item failed. Please try again", Toast.LENGTH_LONG).show();
        }
    }

    //Update item from the item database based on input fields.
    public void updateItem(View view)
    {
        //Get instance of database
        ItemDBHelper db = new ItemDBHelper(this);

        //Create item model from input information
        ItemModel tempItem = new ItemModel(activeItemID, itemName.getText().toString(), itemDescription.getText().toString(), Integer.parseInt(itemQuantity.getText().toString()));

        //Update item in database.
        db.updateItem(activeItemID, tempItem);

        //Check if current item is out of stock and if so, and notifications are allowed
        //Send notification to user.
        if(tempItem.getQuantity() == 0 && allowNotifications)
        {
            Toast.makeText(this, "LOW STOCK", Toast.LENGTH_LONG).show();

            NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "Stock-Channel")
                    .setSmallIcon(R.drawable.ic_launcher_foreground)
                    .setContentTitle("LOW STOCK")
                    .setContentText(tempItem.getName() + " is out of stock")
                    .setPriority(NotificationCompat.PRIORITY_HIGH);

            notificationManager.notify(LOW_STOCK_NOTIF_ID, builder.build());
        }
    }

    //Function to create notification channel
    private void createNotificationChannel() {
        // Create the NotificationChannel, but only on API 26+ because
        // the NotificationChannel class is new and not in the support library
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Stock-Channel";
            String description = "Channel to send low stock notifications";
            int importance = NotificationManager.IMPORTANCE_DEFAULT;
            NotificationChannel channel = new NotificationChannel("Stock-Channel", name, importance);
            channel.setDescription(description);
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }

    //Delete current active item from inventory
    public void deleteItem(View view)
    {
        //Get instance of database
        ItemDBHelper db = new ItemDBHelper(this);

        //Delete item and return result
        boolean result = db.deleteItem(activeItemID);

        //Show result as toast
        if(result)
            Toast.makeText(this, "Item Deleted Successfully", Toast.LENGTH_LONG).show();
        else
            Toast.makeText(this, "Delete Action Failed", Toast.LENGTH_LONG).show();

        //Return to MainActivity Screen
        Intent switchActivityIntent = new Intent(this, MainActivity.class);
        startActivity(switchActivityIntent);
    }

}